import xbmcgui
import xbmc 

def progress():
	pDialog = xbmcgui.DialogProgress()
	while True:
		pDialog.create('Ribelo', 'Cargando Documentales')
		pDialog.update(20,'Ribelo:','Buscando Documentales.')
		xbmc.sleep(500)
		pDialog.update(40,'Ribelo:','Buscando Documentales.')
		xbmc.sleep(500)
		pDialog.update(60,'Ribelo:','Buscando Documentales.')
		xbmc.sleep(500)
		pDialog.update(75,'Ribelo:','Buscando Documentales.')
		xbmc.sleep(500)
		pDialog.update(85,'Ribelo:','Buscando Documentales.')
		xbmc.sleep(500)
		xbmc.sleep(1000)
		pDialog.update(100,'Ribelo:','Buscando Documentales.')
		break

