#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
 Author: enen92 

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 
"""

import urllib
import json
import re
import os
import sys
import math
import xbmcaddon
import xbmcplugin
from common_variables import *
from directory import *
from youtubewrapper import *

def search():
	kb = xbmc.Keyboard('default', 'heading')
	kb.setDefault('')
	kb.setHeading('Busqueda de Documentales')
	kb.setHiddenInput(False)
	kb.doModal()
	if kb.isConfirmed():
		search_term = kb.getText()
		return(search_term)
	else:
		return
		
def get_search_videos():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+'+search()+'%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_new():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales%2C+long%2C+hd%2C+video&search_sort=video_date_uploaded&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_pale():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+paleolitico%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_neo():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+edad+de+piedra%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)
		
def get_search_metal():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+edad+de+los+metales%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)		

def get_search_mesopotamia():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documental+mesopotamia+%2C+hd%2C+long%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_egipto():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documental+imperio+egiptcio+%2C+hd%2C+long%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_griego():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documental+imperio+griego+%2C+hd%2C+long%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)
		
def get_search_roma():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documental+imperio+romano+%2C+hd%2C+long%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_media():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documental+edad+media+%2C+hd%2C+long%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_anarquismo():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+anarquismo%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_comunismo():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+comunismo%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)
		
def get_search_nacionalismo():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+nacionalismo%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)
		
def get_search_capitalismo():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+capitalismo%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_colonialismo():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+colonialismo%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_imperialismo():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+imperialismo%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_primera():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+primera+guerra+mundial%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

def get_search_revolucion():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+revolucion+rusa%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)
		
def get_search_segunda():
	list_of_tupple_items = []
	
	url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=documentales+segunda+guerra+mundial%2C+long%2C+hd%2C+video&type=video&maxResults=50&key='+youtube_api_key
	raw = urllib.urlopen(url)
	resp = json.load(raw)
	raw.close()
	if resp["items"]:
		video_ids = []
		for item in resp["items"]:
			videoid = item["id"]["videoId"]
			video_ids.append(videoid)
		video_ids = ','.join(video_ids)
		url_api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='+video_ids+'&key='+youtube_api_key
		raw = urllib.urlopen(url_api)
		resp = json.load(raw)
		raw.close()
		
		for item in resp["items"]:
			title = item["snippet"]["title"]
			plot = item["snippet"]["description"]
			thumb = item["snippet"]["thumbnails"]["high"]["url"]
			aired = item["snippet"]["publishedAt"]
			videoid = item["id"]
			episode = re.findall('(\d+)',title)
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			
			infolabels = {'plot':plot.encode('utf-8'),'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'aired':aired,'date':date,'status':status,'cast':cast,'episode':episode,'playcount':0}
			#process duration
			duration_string = item["contentDetails"]["duration"]
			try: duration = return_duration_as_seconds(duration_string)
			except: duration = '0'
			try: 
				aired = re.compile('(.+?)-(.+?)-(.+?)T').findall(aired)[0]
				date = aired[2] + '.' + aired[1] + '.' + aired[0]
				aired = aired[0]+'-'+aired[1]+'-'+aired[2]
			except: 
				aired = ''
				date = ''
			try:
				if episode_playlists:
					if url in episode_playlists:
						episode = re.compile('(\d+)').findall(title)[0]
					else: episode = ''
				else: episode = ''
			except: episode = ''
			#playcount
			if os.path.exists(os.path.join(watchedfolder,str(videoid)+'.txt')) : playcount = 1
			else: playcount = 0
		
			infolabels = {'plot':plot.encode('utf-8'),'aired':aired,'date':date,'tvshowtitle':tvshowtitle,'title':title.encode('utf-8'),'originaltitle':title.encode('utf-8'),'status':status,'cast':cast,'duration':duration,'episode':episode,'playcount':playcount}
			
			#Video and audio info
			video_info = { 'codec': 'avc1', 'aspect' : 1.78 }
			audio_info = { 'codec': 'aac', 'language' : 'en' }
			try:
				if item["contentDetails"]["definition"].lower() == 'hd':
					video_info['width'] = 1280
					video_info['height'] = 720
					audio_info['channels'] = 2
				else:
					video_info['width'] = 854
					video_info['height'] = 480
					audio_info['channels'] = 1
				try:
					if xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality.ask') == 'false' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '3' and xbmcaddon.Addon(id='plugin.video.youtube').getSetting('kodion.video.quality') != '4':
						video_info['width'] = 854
						video_info['height'] = 480
						audio_info['channels'] = 1
				except: pass	
			except:
				video_info['width'] = 854
				video_info['height'] = 480
				audio_info['channels'] = 1		
			
			#build and append item
			tupple = build_episode_item(title.encode('utf-8'),videoid,5,thumb,1,infolabels,video_info,audio_info)
			list_of_tupple_items.append(tupple)
		
		if list_of_tupple_items:
			number_of_items = len(list_of_tupple_items)
			xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_of_tupple_items,totalItems=number_of_items)
			add_sort_methods()
				
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	else:
		msgok(translate(30000),translate(30002))
		sys.exit(0)

