from resources.lib.youtubewrapper import *
import YDStreamUtils
import YDStreamExtractor
YDStreamExtractor.disableDASHVideo(True)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None

try: url=urllib.unquote_plus(params["url"])
except: pass

url = url
vid = YDStreamExtractor.getVideoInfo(url,quality=1)
path = selfAddon.getSetting('folder')


def youtube_dl():
	with YDStreamUtils.DownloadProgress() as prog: #This gives a progress dialog interface ready to use
		try:
			YDStreamExtractor.setOutputCallback(prog)
			result = YDStreamExtractor.downloadVideo(vid,path)
			if result:
				#success
				full_path_to_file = result.filepath
			elif result.status != 'canceled':
				#download failed
				error_message = result.message
		finally:
			YDStreamExtractor.setOutputCallback(None)
