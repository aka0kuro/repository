#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
 Author: enen92 

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 
"""

import urllib,xbmcplugin
import os,sys
from resources.lib.common_variables import *
from resources.lib.directory import *
from resources.lib.youtubewrapper import *
from resources.lib.watched import * 
from resources.lib.youtube_dl import * 
from resources.lib.search_videos import * 
from resources.lib.progress_dialog import * 

"""

Addon navigation is below
 
"""	
		
            
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
page = None
token = None
number_of_items = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except:
	try: 
		mode=params["mode"]
	except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: token=urllib.unquote_plus(params["token"])
except: pass
try: page=int(params["page"])
except: page = 1

print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("iconimage: "+str(iconimage))
print ("Page: "+str(page))
print ("Token: "+str(token))

def main_menu():
	addDir('[COLOR red]•[/COLOR] [COLOR white][B][I]Buscador[/B][/I][/COLOR]','',10,os.path.join(artfolder,'buscador.png'),1,1,'')
	addDir('[COLOR red]•[/COLOR] [COLOR white][B][I]Ultimos Documentales[/B][/I][/COLOR]','',28,os.path.join(artfolder,'buscador.png'),1,1,'')
	addDir('[COLOR red]•[/COLOR] [COLOR white][B][I]Historia[/B][/I][/COLOR]','','histori_list',os.path.join(artfolder,'historia.png'),1,1,'')
	addDir('[COLOR red]•[/COLOR] [COLOR white][B][I]Politica[/B][/I][/COLOR]','','politic_list',os.path.join(artfolder,'Politica.png'),1,1,'')
	addDir('[COLOR red]•[/COLOR] [COLOR white][B][I]Naturaleza[/B][/I][/COLOR]','','naturaleza_list',os.path.join(artfolder,'Politica.png'),1,1,'')

def histori_list():
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Prehistoria[/B][/I][/COLOR]','','prehistoria_list',os.path.join(artfolder,'prehistoria.png'),1,1,'')
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Edad Antigua[/B][/I][/COLOR]','','antigua_list',os.path.join(artfolder,'icon.png'),1,1,'')
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Edad Media[/B][/I][/COLOR]','',27,os.path.join(artfolder,'icon.png'),1,1,'')
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Colonialismo[/B][/I][/COLOR]','',15,os.path.join(artfolder,'icon.png'),1,1,'')
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Imperialismo[/B][/I][/COLOR]','',16,os.path.join(artfolder,'icon.png'),1,1,'')
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Primera Guerra Muldial[/B][/I][/COLOR]','',17,os.path.join(artfolder,'icon.png'),1,1,'')
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Revolución Rusa[/B][/I][/COLOR]','',18,os.path.join(artfolder,'icon.png'),1,1,'')
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Segunda Guerra Muldial[/B][/I][/COLOR]','',19,os.path.join(artfolder,'icon.png'),1,1,'')

def antigua_list():
	addDir('[COLOR red]-[/COLOR] [COLOR white][B][I]Mesopotamia[/B][/I][/COLOR]','',23,os.path.join(artfolder,'icon.png'),1,1,'')
	addDir('[COLOR red]-[/COLOR] [COLOR white][B][I]Egiptcios[/B][/I][/COLOR]','',24,os.path.join(artfolder,'icon.png'),1,1,'')
	addDir('[COLOR red]-[/COLOR] [COLOR white][B][I]Griegos[/B][/I][/COLOR]','',25,os.path.join(artfolder,'icon.png'),1,1,'')
	addDir('[COLOR red]-[/COLOR] [COLOR white][B][I]Romanos[/B][/I][/COLOR]','',26,os.path.join(artfolder,'icon.png'),1,1,'')
	
def prehistoria_list():
	addDir('[COLOR red]-[/COLOR] [COLOR white][B][I]Paleolítico[/B][/I][/COLOR]','',20,os.path.join(artfolder,'paleolitico.png'),1,1,'')
	addDir('[COLOR red]-[/COLOR] [COLOR white][B][I]Edad de Piedra [/B][/I][/COLOR]','',21,os.path.join(artfolder,'piedra.png'),1,1,'')
	addDir('[COLOR red]-[/COLOR] [COLOR white][B][I]Edad de los Metales[/B][/I][/COLOR]','',22,os.path.join(artfolder,'metales.png'),1,1,'')

def naturaleza_list():
	addDir('[COLOR red]-[/COLOR] [COLOR white][B][I]Paleolítico[/B][/I][/COLOR]','',20,os.path.join(artfolder,'paleolitico.png'),1,1,'')
	addDir('[COLOR red]-[/COLOR] [COLOR white][B][I]Edad de Piedra [/B][/I][/COLOR]','',21,os.path.join(artfolder,'piedra.png'),1,1,'')
	addDir('[COLOR red]-[/COLOR] [COLOR white][B][I]Edad de los Metales[/B][/I][/COLOR]','',22,os.path.join(artfolder,'metales.png'),1,1,'')

def politic_list():
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Anarquismo[/B][/I][/COLOR]','',11,os.path.join(artfolder,'anarquismo.png'),1,1,'')
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Comunismo[/B][/I][/COLOR]','',12,os.path.join(artfolder,'comunismo.png'),1,1,'')
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Nacionalismo[/B][/I][/COLOR]','',13,os.path.join(artfolder,'nacionalismo.png'),1,1,'')
	addDir('[COLOR red]*[/COLOR] [COLOR white][B][I]Capitalismo[/B][/I][/COLOR]','',14,os.path.join(artfolder,'capitalismo.png'),1,1,'')

if mode==None: main_menu()
elif mode=='politic_list': politic_list()
elif mode=='histori_list': histori_list()
elif mode=='prehistoria_list': prehistoria_list()
elif mode=='antigua_list': antigua_list()
elif mode==1: return_youtubevideos(name,url,token,page)
elif mode==5: play_youtube_video(url)
elif mode==6: youtube_dl()
elif mode==10: get_search_videos()
elif mode==11: progress(),get_search_anarquismo()
elif mode==12: progress(),get_search_comunismo()
elif mode==13: progress(),get_search_nacionalismo()
elif mode==14: progress(),get_search_capitalismo()
elif mode==15: progress(),get_search_colonialismo()
elif mode==16: progress(),get_search_imperialismo()
elif mode==17: progress(),get_search_primera()
elif mode==18: progress(),get_search_revolucion()
elif mode==19: progress(),get_search_segunda()
elif mode==20: progress(),get_search_pale()
elif mode==21: progress(),get_search_neo()
elif mode==22: progress(),get_search_metal()
elif mode==23: progress(),get_search_mesopotamia()
elif mode==24: progress(),get_search_egipto()
elif mode==25: progress(),get_search_griego()
elif mode==26: progress(),get_search_roma()
elif mode==27: progress(),get_search_media()
elif mode==28: progress(),get_search_new()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
